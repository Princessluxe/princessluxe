import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

// IMPORTANT: set this to "/YOUR-REPO-NAME/" to match your GitHub repository
// name exactly (including the slashes). This is required for GitHub Pages
// to load your CSS/JS correctly from a github.io/REPO-NAME URL.
export default defineConfig({
  plugins: [react()],
  base: "/princesshairluxe/",
});
